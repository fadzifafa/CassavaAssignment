### Developer Task 1 

* You will receive instructions from Cassava Smartech on what's required.


INSERT INTO e_req_partner (id, code, name, description)
VALUES (123, 'hot-recharge', 'Hot Recharge', 'HOT RECHARGE PLATFORM');